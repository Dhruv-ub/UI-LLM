---
name: Luminous Intelligence
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#ffafd3'
  on-tertiary: '#620040'
  tertiary-container: '#e364a7'
  on-tertiary-container: '#560038'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#ffd8e7'
  tertiary-fixed-dim: '#ffafd3'
  on-tertiary-fixed: '#3d0026'
  on-tertiary-fixed-variant: '#85145a'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  code:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 0.5rem
  sm: 1rem
  md: 1.5rem
  lg: 2.5rem
  xl: 4rem
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The design system is engineered for high-performance AI SaaS environments where clarity and technical sophistication intersect. It evokes a sense of "digital craftsmanship"—clean, intentional, and premium.

The visual style is **Glassmorphic Minimalism**. It prioritizes deep, immersive backgrounds with translucent UI layers that create a sense of depth and focus. By blending the structured efficiency of productivity tools with the fluid, ethereal nature of modern AI, the interface feels both powerful and approachable. The emotional response should be one of "effortless intelligence."

## Colors
The palette is rooted in a deep "Midnight" neutral to ensure high contrast and visual comfort during long sessions. 

- **Primary & Secondary:** A vibrant Indigo-to-Violet gradient serves as the core brand signal, used for primary actions, progress indicators, and AI-driven states.
- **Glass Surfaces:** Semi-transparent grays (e.g., `rgba(30, 41, 59, 0.7)`) are used for panels, paired with a 1px "inner glow" border to define edges without adding visual weight.
- **Accents:** Tertiary pink is reserved for high-value highlights or specific AI "magic" moments.
- **Feedback:** Use standard semantic colors (Success: Emerald, Warning: Amber, Error: Rose) but desaturate them slightly to fit the dark aesthetic.

## Typography
The typography system utilizes **Geist** for structural elements (headings, labels, UI controls) to maintain a technical, precise feel. **Inter** is used for long-form body text and AI chat outputs to maximize readability.

Large display headings should use tighter letter spacing and bold weights to command attention. For AI-generated content, use a slightly increased line-height (1.6) to reduce cognitive load during reading.

## Layout & Spacing
This design system employs a **12-column fluid grid** for desktop and a **single-column stack** for mobile. 

- **The Container:** Content is housed in "Glass Cards" that float over the deep background. 
- **Rhythm:** Use a 4px baseline grid. All padding and margins should be multiples of 8px to ensure mathematical harmony.
- **Desktop:** 12 columns, 24px gutters, and 48px side margins.
- **Tablet:** 8 columns, 16px gutters, 32px side margins.
- **Mobile:** 4 columns, 16px gutters, 16px side margins.

## Elevation & Depth
Depth is created through **Backdrop Blurs** and **Tonal Layering** rather than traditional heavy shadows.

- **Level 0 (Background):** Solid `#0F172A`.
- **Level 1 (Main Surfaces):** Subtly lighter `#1E293B` with a 1px border (`rgba(255,255,255,0.08)`).
- **Level 2 (Floating Modals/Popovers):** `rgba(30, 41, 59, 0.8)` with a 20px Backdrop Blur and a soft, diffused Indigo-tinted shadow (`0 20px 40px rgba(0,0,0,0.4)`).
- **The "AI Glow":** Active elements or AI processing states should feature a subtle outer glow using the primary Indigo color at low opacity.

## Shapes
The shape language is friendly yet structured. This design system uses **rounded-2xl** (1rem / 16px) as the standard for primary containers and buttons.

- **Small Components (Chips/Inputs):** 0.5rem (8px).
- **Standard Cards:** 1rem (16px).
- **Large Sections:** 1.5rem (24px).
- **Contextual Pill:** Use full-radius (pill-shaped) exclusively for status indicators and high-priority tags.

## Components
- **Buttons:** Primary buttons use the Indigo-to-Violet gradient with white text. Secondary buttons are "Ghost" style: transparent backgrounds with a 1px white-border (10% opacity) that brightens on hover.
- **Inputs:** Dark backgrounds (`#020617`) with a 1px border. On focus, the border transitions to the primary gradient and a subtle 2px outer glow.
- **Cards:** Use the glassmorphic style—20px blur, 1px border, and a slight vertical gradient from top-left to bottom-right to simulate light hitting the surface.
- **AI Chat Bubbles:** User messages should be subtle (dark gray), while AI responses should be framed with a very thin, glowing border or a slight gradient background to distinguish "Machine" from "Human."
- **Chips:** Small, pill-shaped elements with low-opacity background fills (e.g., Indigo at 10% opacity) and high-contrast text.
- **Progress Bars:** Use a shimmering "loading" animation across the primary gradient to indicate AI "thinking" time.